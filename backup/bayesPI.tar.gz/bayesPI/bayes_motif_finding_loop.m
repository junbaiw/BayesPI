function [record_net,x_binary,new_t]=bayes_motif_finding_loop(fileexp,fileseq,L,max_loop,seed,nhidden,...
    out_fold,selection_percentage,pcutoff,fileann,filenucleosome,isreverse,isrepeat)
global isnucleosome
%fileexp= expression file name
%fileseq= sequences file name
%L = motif length
%max_loop= maximum number of motifs
format long e
if  nargin==11
	isreverse=0;	%this experiment issnot reversed defalut settinga
	disp('This is not a reversed experiment!')
end

t11=clock;
%Input data parameters
randn('state',0); %ceil(abs(randn)*100));
rand('state',0);  %ceil(abs(randn)*100));
%the random initial values to the weights will effect the final estimations


%Read expression data
[t1,t_cases1,t_vars1]=tblread2(fileexp,'\t');
t_vars1=strrep(cellstr(t_vars1),'_','');	%remove all the _ in ids
if isreverse==1
	disp('This is a reversed experiment!')
	t1=-t1;	
	%if the experiment is reverse designed
end 

if min(t1)<0
	t1=2.^t1;	%transform to real ratios 
end

%read features
if exist(fileann)
	for ii=1:size(t_vars1,1)
		new_t_vars1{ii}=strrep(t_vars1(ii,:),'-','');	
	end
	[fdata,fv,fc]=tblread2(fileann,'\t');
	telomere=fdata(:,strmatch('telomere',fv) );
	[newcc,aci,bci]= intersect(lower(deblank(new_t_vars1')),cellstr(lower(fc)));
	
	new_t_vars1=cellstr(t_vars1(aci,:));
	new_fc=cellstr(fc(bci,:));
	new_t1=t1(aci,:);
	new_telomere=telomere(bci);
	idx1=find(new_telomere==0);
	new_t1_2=new_t1(idx1,:);
        new_t_vars1_2=strvcat(new_t_vars1(idx1));	
	t1=[];
	t1=new_t1_2;
  	t_vars1=[];
	t_vars1=new_t_vars1_2;	
end

%remove NAN
idx_nan=find(~isnan(t1));
t0=t1(idx_nan,:);
t_cases=t_cases1;
t_vars0=t_vars1(idx_nan,:);

%select subset datasets
%[st,sti]=sort(t0,'descend');
[ost,osti]=sort(t0);    %sort in descend order
st=ost(end:-1:1);sti=osti(end:-1:1);

if isempty(selection_percentage)
       selection_percentage=1;
end
st_vars=t_vars0(sti,:);

%compute percent of genes has >= ratios
num_of_good=length(find(st>=2));
num_of_total=length(st);

%we define at least 0.1 percent of input data has ratios >=2
num_of_input=ceil(num_of_good/selection_percentage);
idx_gene_selection=1:length(st);
new_idx_gene=idx_gene_selection(1:ceil(num_of_total*selection_percentage)); %num_of_input);      %ceil(num_of_total*selection_percentage));
t=[]; t_vars=[];
t=st(new_idx_gene);
t_vars=st_vars(new_idx_gene,:);

%read sequence data
[gene_id,gene_seq,gene_seq_idx]=read_seq_fa(fileseq);
gene_id=strrep(gene_id,'_',''); %remove all the _ in the ids 
disp(['Select ', num2str(selection_percentage), ' of input data !']);

%take an intersection between sequence and expression data
if exist('intersect')>0
	[cc,ai,bi]=intersect(strvcat(lower(deblank(gene_id))),strvcat(lower(deblank(t_vars))),'rows');
	if prod(size(cc))<1 
		warning('No match was found between sequences and experssion data!');	 
	end
else
	cc=[];
	loop=1;
	for i=1:length(gene_id)
        	tp=strmatch(lower(deblank(gene_id{i})),lower(deblank(t_vars)),'exact');
        	if ~isempty(tp)
                	ai(loop)=i;
               	bi(loop)=tp(1);
                	cc{loop}=lower(deblank(gene_id{i}));
                	loop=loop+1;
 	      	end
	end
end
new_id=cc;
if length(find(t(bi,:)<0))==0
	disp('Log transform of input data')
	new_t= log(t(bi,:));   %log2 transform of expression data if it is real ratios
else
	new_t=(t(bi,:));
	disp(' the input is Log transformed  data')
end

%Remove outlier there is a problem when nan appear in the input data
out_alpha=pcutoff/size(find(~isnan(new_t)),1) %0.000001 %0.001; %for some data we may need p=0.000001 for example bas1 and fhl1
out_rep=1;
[b,idx,outliers] = deleteoutliers(new_t,out_alpha,out_rep);
new_t=[];
nan_idx=find(~isnan(b));
new_t=exp(b(nan_idx));
disp(['Grubbs test to remove ', num2str(size(find(~isnan(outliers)),1)),' outliers ...' ]);
disp(['All input data are transformed back to Real ratios!']);

%remove NAN
t_new_id=new_id;
new_id=[];
new_id=t_new_id(nan_idx,:);
t_new_seq=gene_seq_idx(ai,:);
new_seq=t_new_seq(nan_idx,:);
t_new_seq_str=gene_seq(ai);
new_seq_str=t_new_seq_str(nan_idx);
clear t_new_id t_new_seq t_new_seq_str b idx outliers cc ai bi t

%read nucleosome file
mean_new_nuc_t=[];
isnucleosome=0;
if ~isempty(filenucleosome)
    isnucleosome=1;
    [nuc_data,nuc_vars,nuc_cases]=tblread2(filenucleosome,'\t');
    for i=1:size(nuc_cases,1)
        temp=nuc_cases(i,:);
        idx=findstr(':',temp);
        temp_cases=temp(1:idx-1);    
        new_nuc_cases(i)=cellstr(lower(temp_cases));
    end
    disp('Read nucleosome data')
    [nuc_c,nuc_cia,nuc_cib]=intersect(new_nuc_cases,cellstr(deblank(lower(new_id))));
    len_nuc=length(nuc_c);
    disp(['Find ',num2str(len_nuc), ' of ',num2str(size(new_id,1)),' probes have nucleosome data']);
    t_new_id=new_id;
    new_id=[]; new_id=t_new_id(nuc_cib,:);
    t_new_t=new_t; new_t=[]; new_t=t_new_t(nuc_cib,:);
    t_new_seq=new_seq; new_seq=[]; new_seq=t_new_seq(nuc_cib,:);
    t_new_seq_str=new_seq_str; new_seq_str=[]; new_seq_str=t_new_seq_str(nuc_cib);
    new_nuc_t=nuc_data(nuc_cia,:);
    mean_new_nuc_t=[];
    for ki=1:size(new_nuc_t,1)
        temp=new_nuc_t(ki,:);
        temp_idx=[];
        temp_idx=find(~isnan(temp));
        mean_new_nuc_t(ki)=mean(temp(temp_idx));
    end
   % hist(new_nuc_t)
   % [cellstr(new_id),new_nuc_cases(nuc_cia)']
    clear t_new_id t_new_t t_new_seq t_new_seq_str
end
%%%%%
ndata = size(new_t,1);
max_col=max(find(sum(new_seq,1)));
x=new_seq(:,1:max_col); %gene_seq_idx;
disp(['Read: gene ',num2str(size(new_t,1)),'; sequence length ',num2str(max_col)])

%motif length
%for saving memory
clear t1 t_cases1 t_vars1 gene_id gene_seq new_seq_str new_seq cc bi ai gene_seq_idx;

%this part can be removed if donot need compute the motif counts
%[motif_counts,all_motifs,oligo_pro,total_bases,seqs_len]=compute_motif_counts(new_seq_str,L,max_col);
%motif_counts
%motif_counts=4096 %6m
disp('Finishing read data and motif counts ....')

% Set up network parameters.
med_N=median(sum(x>0,2));    %
N=size(x,2);  %sequence length
%L=8;    %motif length plus 2 flank region in each site
nin = N*4;			% Number of sequence base times 4.
if isempty(nhidden)
	nhidden=1;			% Number of hidden units.
end
nout = 1;			% Number of outputs.
aw1 = 0.01; %repmat( 0.01,1,L);         %*ones(1, nin);	% First-layer ARD hyperparameters.
ab1 = 0.01;			% Hyperparameter for hidden unit biases.
aw2 = 0.01;			% Hyperparameter for second-layer weights.
ab2 = 0.01;			% Hyperparameter for output unit biases.
coupling =[ ];		% add 2 Hyperparameter for coupling weight in W1
beta =50;			% Coefficient of data error.

%transform sequence x to binary representation of sequence For example,
%A=[ACGT -> 1000],C=[ACGT -> 0100],G=[ACGT -> 0010],T=[ACGT -> 0001],
%transform x to sequence index,
x_binary=sequence2binary(x,isrepeat);
if ~isrepeat
	each_seq_len=sum(x_binary,2);
else
	for ii=1:size(x,1)
		each_seq_len(ii)=max(find(x(ii,:)>0));
	end
end
clear x t0 %for saving memory

% Set up vector of options for the optimiser.
nouter = 5;			% Number of outer loops
ninner = 10;		        % Number of inner loops
options = zeros(1,18);		% Default options vector.
options(1) = 0;			% This provides display of error values.
options(2) = 1.0e-7;	% This ensures that convergence must occur
options(3) = 1.0e-7;
options(14) = 500;		% Number of training cycles in inner loop. 
%options(9)=1; 	%check gradient
%net.motif_counts=motif_counts;

%start to do motif search
record_net=[];
all_loop=1;
disp('Start to compute PWM ....')
out_string=['save ', out_fold,'/',fileexp,'_mlpout_motifL',num2str(min(L)),'_',num2str(max(L)),'.mat']

%loop in motif L
for ii=1:length(L);
	%Initial weights
	L(ii)
	motif_counts=4^L(ii)
	net.motif_counts=motif_counts;
	loop=1;
	prior = wang_mlpprior(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);
	net = wang_mlp(nin, nhidden, nout, 'linear', prior, beta,N,L(ii),each_seq_len,med_N,seed,isnucleosome);
	target=new_t;
    target_nuc=som_normalize(mean_new_nuc_t','var');	%transform to Zscores
	disp('Initial values')
    if isnucleosome
	
	    reshape(net.w1(1:end-1*net.nhidden,1),4,L(ii)),
        [net.w1(end-1*net.nhidden+1:end),net.b1,net.w2,net.b2]
    else
        reshape(net.w1(1:end),4,L(ii)),[net.b1,net.w2,net.b2]
    end
	while loop<=max_loop
		for k=1:nouter
				disp('estimate w2 ...')
                if isnucleosome
                    [net, soptions, svarargout] = wang_netopt(net, options, x_binary,(target),target_nuc,'scgC_nucleosome');
                else
                     [net, soptions, svarargout] = wang_netopt(net, options, x_binary,(target),target_nuc,'scgC');
                end
    			disp('Do evidence inference ...');
			    [net, gamma] = wang_evidence_nucleosome(net, x_binary, (target),target_nuc, ninner);     %some error in
           
    			% the evidence computations??
                if isnucleosome
    			    reshape(net.w1(1:end-1*net.nhidden,1),4,L(ii)),net.alpha, net.beta
                else
                    reshape(net.w1,4,L(ii)),net.alpha, net.beta
                end
    			[k,soptions(10)]
    			%if soptions(10)<options(14)  %stop to search if it is converged
    			% 		break;
    			%end
		end
		net.motif_counts=motif_counts; 
		net.each_seq_len=each_seq_len;
        [fy,fz,fa]=wang_mlpfwdC(net,x_binary');
		old_target=target;
		target=fy-(target);
	
		%Added to test regression fit
        kf=1;
        Nf=length(fy);
		SS_resid=sum((fy-old_target).^2,1);
		%standar error of estimate
		SE_yx=sqrt(SS_resid/(Nf-kf-1));
		%squared correlation coefficient x variable explains 
		s_XX=(fz-mean(fz,1));
		sum_XX=sum(s_XX.^2,1);
		sum_YY=sum((old_target-mean(old_target)).^2);
		sum_XY=(fz-mean(fz))'*(old_target-mean(old_target)); ;%here not include intercepte 
		r_xy=sum_XY./sqrt(sum_XX*sum_YY);
		r_squre=r_xy.^2                 %Coefficient_of_determination
		F2=r_xy.^2./kf/(1-r_xy.^2)*(Nf-kf-1)

		%Test of regression coefficient
		%Standard error of regression coefficient
		SE_b=SE_yx./sqrt((sum_XX));
		tt=net.w2./SE_b;    %t value to motif weight
		df=Nf-net.nwts-1;
        pt=2*(1-tcdf2(abs(tt),df))*motif_counts
        
		%Test of regression model,here we need remove the first constant intercepte
		%term , in general regression
		SS_reg=(sum_XY).^2./sum_XX;
		SS_res=sum_YY-SS_reg;
		F0=SS_reg/kf./(SS_res/(Nf-kf-1))
		df1=kf;df2=Nf-kf-1;
		%pt=(1-fcdf(F0,df1,df2))*motif_counts ;%%bonferroni correction ??

        T0=sqrt(F0) %t value to regression fit
        total_p=2*(1-tcdf2(abs(T0),Nf-1))*motif_counts
        %%end added       
        
        %test sum square of errors
	 	%ssr=sum((fy-mean(old_target)).^2);
 		%sse=sum((fy-old_target).^2);
        %sst=sum((old_target-mean(old_target)).^2);
        %F=ssr/sse
        %r2=ssr/sst
		%1-sse/sst

                %convert r2 to t values
                %r0=(1.63+0.58*df)/sqrt(size(target,1));
                %sigma=0.66/sqrt(size(target,1));
                %t=abs(sqrt(r2)-r0)/sigma
        	    %comput p of t values
                %ppt=1/sqrt(df)/beta(1/2,17)*(1+t^2/df)^((-df-1)/2)
      		
		        %[rr,rrp]=corrcoef(fy,old_target)  
                %tt=rr(1,2)*sqrt((size(find(~isnan(target)),1)-2)/(1-rr(1,2)^2))
                %pt=2*(1-tcdf(tt,motif_counts-1))  %bonferroni correction ??
 
                if ((total_p>0.0001 | pt > 0.0001 )& loop>10 )
			disp('No information available in the data, I runed at least three times then stop!');
			break;
		else
                        %make new predictions
                         net.F=F2;
                         net.r2=r_squre; net.total_p=total_p;net.motif_p=pt; net.motif_t=tt;
                     	 net.each_seq_len=[]	; %for saving memory
			             record_net{all_loop}=net;
                         loop=loop+1;
                         all_loop=all_loop+1;
			
			            record_net,fileexp,L,out_fold	
			            %export data
			            export2AffinityLogo(record_net,fileexp,L,out_fold);                       
		    		    eval(out_string);
 
                         % Create and initialize network.
                         prior = wang_mlpprior(nin, nhidden, nout, aw1, ab1, aw2, ab2,coupling, N,L(ii),isnucleosome);
                         net = wang_mlp(nin, nhidden, nout, 'linear', prior, beta,N,L(ii),each_seq_len,med_N,seed,isnucleosome);
                	     motif_counts=motif_counts-1;
		                 net.motif_counts=motif_counts;
                         net.each_seq_len=sum(x_binary,2);
        end
		loop	
		%pause
	end
end

out_string=['save ', out_fold,'/',fileexp,'_mlpout_motifL',num2str(min(L)),'_',num2str(max(L)),'.mat']
eval(out_string);
etime(clock,t11)

% Train using scaled conjugate gradients, re-estimating alpha and beta.

