clear all;close all;
%make gene ratios
%randn('seed',0)
randn('state', 0);
num_of_genes=100;
t=randn(1,num_of_genes);   %target

%make motif
chars = ['a', 'c', 'g', 't'];
motif = lower('GCTGGT') %lower('CATGTGAAAT')  %lower('CACGAAAA')  %lower('GCCTCGAAGCGA'); %lower('gggctc')      %'tcattgg');
%Swi4:	CACGAAAA
%INO4:	CATGTGAAAT
%ACE2:	GCTGGT
%XBP1:  GCCTCGAAGCGA

motif_length = length(motif);
l=motif_length;
motif_code=least_makeMotif(motif);
total_x=2+4*l+1
e_x=2+4*l;

%Make 5k random sequence for testing
seq_length=1000;
[cases,cases_m]=least_makeSequence(seq_length,num_of_genes,motif,motif_code,t);

%export sampled sequence and expression data
disp('sample training cases')
OUTfid=fopen(['demo_',num2str(seq_length/1000),'Kseq','_',motif ,'.fa'],'w');
OUTfid2=fopen(['demo_',num2str(seq_length/1000),'Kseq','_',motif,'.txt'],'w');
fprintf(OUTfid2,'%s%s%s\n','ID',char(9),'ratios');
for i=1:num_of_genes
  fprintf(OUTfid,'%s \n',['>gene', num2str(i)]);
  fprintf(OUTfid,'%s \n', chars(cases{i}));
  fprintf(OUTfid2,'%s %s %s \n',['gene', num2str(i)],char(9), num2str(t(i)));
end
fclose(OUTfid);
fclose (OUTfid2);
disp(['Sequence file: ','demo_',num2str(seq_length/1000),'Kseq','_', motif,'.fa'])
disp(['Expression file: ','demo_',num2str(seq_length/1000),'Kseq','_' ,motif,'.txt'])

