function [com_seq,com_seq_idx]=seq_anti_strand(gene_seq,gene_seq_idx)
%this function is transform sequence to its antistrand sequence both string and seq index.

chars = {'a', 'c', 'g', 't'};
com_idx=[4,3,2,1];
max_col=max(find(sum(gene_seq_idx,1)));
max_row=length(gene_seq);
com_seq=cell(1,max_row);
com_seq_idx=zeros(max_row,max_col);
for i=1:max_row
	str=gene_seq{i};
	str_idx=gene_seq_idx(i,:);
	com_gene_idx=[];
	for j=1:4
            idx_s=[];
            idx_s=findstr(chars{j},lower(str));
            com_gene_idx(idx_s)=com_idx(j);
        end
	len_seq=length(com_gene_idx);
	order=sort(1:len_seq,'descend');
	com_seq_idx(i,order)=com_gene_idx;
	end_idx=find(com_seq_idx(i,:)==0);
	if isempty(end_idx)
		end_idx=max_col;
	end
	com_seq{i}= strvcat(chars(com_seq_idx(i,1:end_idx-1)))';
end
