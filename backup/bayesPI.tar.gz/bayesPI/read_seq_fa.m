function [gene_id2,gene_seq2,gene_seq_idx2]=read_seq_fa(fileseq)
%read sequence in fast file format 
%
chars = {'a', 'c', 'g', 't'};
[fid,msg]=fopen(fileseq,'rt');
if fid<0
    error('Can not open file');
end 
idx=1; 
idx2=1;
gene_seq_idx=[];
ishead=0;
tstring=[];
max_seq_len=1000;	%the default is 3000 but for multiple species it is 150 : This parameter may need change
gene_seq=cell(1,100000); %here the gene number change be changed if it is needed!
gene_id=cell(1,100000);
loop=1;
gene_seq_idx=zeros(100000,max_seq_len);
while 1 
        tline=fgets(fid);
        if ~ischar(tline) 
                break; 
        else
		tline=lower(deblank(tline));
	end 
        is_name=strmatch('>',tline); 
        if ~isempty(is_name) & is_name==1 
                 gene_id{idx}=strrep(deblank(tline(2:end)),char(10),''); 
                idx=idx+1; 
		ishead=1;
        else 
		if ishead==1 & idx >2 %start new id and push all old sequence to the cell
                	gene_idx=[];
                	gene_seq{idx2}=tstring; 
                	gene_idx=zeros(1,max_seq_len); 
                	for i=1:4 
                        	idx_s=[];
                        	idx_s=findstr(chars{i},lower(tstring));
                        	gene_idx(idx_s)=i;
                	end
			%gene_seq_idx=[gene_seq_idx;gene_idx];
             gene_seq_idx(loop,:)=gene_idx;
             loop=loop+1;
			idx2=idx2+1;
			tstring=[];
			tstring=tline;
			ishead=0;
		else
		   	tstring=[tstring,tline];
			ishead=0;
		end
        end
	
end
fclose(fid);

%add last line
gene_idx=[];
gene_seq{idx2}=tstring;
gene_idx=zeros(1,max_seq_len);
for i=1:4
    idx_s=[];
    idx_s=findstr(chars{i},lower(tstring));
    gene_idx(idx_s)=i;
end
%gene_seq_idx=[gene_seq_idx;gene_idx];
gene_seq_idx(loop,:)=gene_idx;
loop=loop+1;
idx2=idx2+1;
tstring=[];
ishead=0;

gene_id2=gene_id(1:idx-1);
gene_seq2=gene_seq(1:idx2-1);
gene_seq_idx2=gene_seq_idx(1:loop-1,:);
%for saving memory
clear gene_id gene_seq
