function [motif_str, motif_energy]=read_bayesianPI_mlp(filename)
[fid,msg]=fopen(filename,'rt');
if fid<0
    error('Can not open file');
end
isrecord=0; 
loop=1;
while 1
    tline = fgets(fid);
    if ~ischar(tline)
        break,
    end
     isfind=strmatch('#',tline);
     if ~isempty(isfind) 
        isrecord=1;
     end
     if isrecord && isempty(isfind)
         colname=marray_tabassign2(tline,5);
        motif_str(loop)=colname{1};
        motif_energy(loop,:)=str2num(strvcat([colname(2:5)]))'; %ACGT
        loop=loop+1;
    end
end

