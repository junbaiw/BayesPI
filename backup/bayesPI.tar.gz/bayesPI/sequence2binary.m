function x_binary=sequence2binary(x,isrepeat)
%transform sequence x to binary representation of sequence For example,
%A=[ACGT -> 1000],C=[ACGT -> 0100],G=[ACGT -> 0010],T=[ACGT -> 0001],
%transform x to sequence index,
[row,col]=size(x);
x_binary=zeros(row,col*4);
if ~isrepeat
	for i=1:row
    		tp_l=x(i,:);
    		iszeros= find(tp_l==0);
    		if ~isempty(iszeros)
        		col1=iszeros(1)-1;
        		col2=iszeros(1);                 
        		tp_l_add=0:4:col1*4;
        		tp_index=tp_l_add(1:col1)+tp_l(1:col1);
        		tp_b=zeros(1,col1*4);
        		tp_b(tp_index)=1;       %real order -> reshape(tp_b,4,col)
        		len_tp_b=length(tp_b);                      %add extra zeros
        		tp_b(len_tp_b+1:col*4)=0;
    		else
        		tp_l_add=0:4:col*4;
        		tp_index=tp_l_add(1:col)+tp_l;
        		tp_b=zeros(1,col*4);
        		tp_b(tp_index)=1;       %real order -> reshape(tp_b,4,col)
    		end
    		x_binary(i,:)=tp_b;
	end
else
	for i=1:row
		tp_1=x(i,:);
		temp_binary=zeros(col,4);
		for k=1:col
			if tp_1(k)~=0
				temp_binary(k,tp_1(k))=1;
			end
		end
		x_binary(i,:)=reshape(temp_binary',1,4*col);
	end
end
	
