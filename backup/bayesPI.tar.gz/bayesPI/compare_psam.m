%read MacIsac matrix in MatrixReduce format

