function [y, z, a,record_tE,record_pE] = wang_mlpfwdE(net, x,p_alpha)
%MLPFWD	Forward propagation through 2-layer network.
%p_alpha is the frequence of  a,c,g,t
%	Description
%	Y = MLPFWD(NET, X) takes a network data structure NET together with a
%	matrix X of input vectors, and forward propagates the inputs through
%	the network to generate a matrix Y of output vectors. Each row of X
%	corresponds to one input vector and each row of Y corresponds to one
%	output vector.
%
%	[Y, Z] = MLPFWD(NET, X) also generates a matrix Z of the hidden unit
%	activations where each row corresponds to one pattern.
%
%	[Y, Z, A] = MLPFWD(NET, X) also returns a matrix A  giving the summed
%	inputs to each output unit, where each row corresponds to one
%	pattern.
%
%	See also
%	MLP, MLPPAK, MLPUNPAK, MLPERR, MLPBKP, MLPGRAD
%
%
%	Copyright (c) Ian T Nabney (1996-2001)
%Modified by Junbai wang, Changing Hidden neuron tanh(x) to 1/(1+ exp(e*x-u))
%current only compute 1 hidden neuron April 30 07

% Check arguments for consistency
errstring = consist(net, 'mlp', x);     %this need change
if ~isempty(errstring);
  error(errstring);
end

ndata = size(x, 1); %number of data point

%added wang
%new sum[1/(1+exp(w*S-b))] based N-L+1 inputs (3)
%set up a function to compute w*x, here x is DNA sequence binary representation
%for example A->1000, C->0100, G->0010, T->0001
z=zeros(ndata,net.nhidden);a=[];

% Prevent overflow and underflow: use same bounds as mlperr
% Ensure that log(1-y) is computable: need exp(a) > eps
maxcut = log(1/realmin - 1);
% Ensure that log(y) is computable
mincut = log(eps);  
record_tE=[];   %zeros(size(x,1),net.sequence_L-net.motif_L+1);
record_pE=[];   %zeros(size(x,1),net.sequence_L-net.motif_L+1);
for i=1:net.sequence_L-net.motif_L+1
    tp_x=x(:,((i-1)*4+1):(i+net.motif_L-1)*4);   
    iszeros= (sum(tp_x,2)>net.motif_L-1) ;	 %remove sequence idx is zeros
    iszeros=repmat(iszeros,1,net.nhidden);	
     	
    aa=tp_x*net.w1-ones(ndata,1)*net.b1; %test
    aa(find(aa<mincut))=mincut;
    aa(find(aa>maxcut))=maxcut;
    tz=1./(1+exp(aa)).*iszeros;			%added Hidden unit 
	
    %added for compute energy E
    tp_alpha=repmat(p_alpha,1,net.motif_L);
    tp_w1=net.w1; 				%reshape(net.w1,4,net.motif_L)';		
    tE=tp_x*net.w1;	
    ki=tp_alpha*(tp_w1.^2);
%    for j=1:size(tp_x,1)
%	t_x=reshape(tp_x(j,:),4,net.motif_L)';
%	ki(j)=sum(sum(tp_alpha.*(tp_w1).^2));
% 	tE(j)= sum(sum(tp_w1.*t_x.*exp(-tp_w1.*t_x).*tp_alpha,2)./sum(exp(-tp_w1.*t_x).*tp_alpha,2)); 
%%	tE(j)=sum(sum(tp_w1.*t_x)); 
%   end
%   ki(find(ki==0))=1;
   pE=exp(-0.5.*(tE.^2)./ki')./sqrt(2*pi*ki');
   tz=tz.*pE;
   record_tE(i,:)=tE;
   record_pE(i,:)=pE;
   i
    %end added E	
	
    %find oligo prob
    if isfield(net,'motif_p');
    	[str_p]=net.motif_p(:,i);	%index2char(tp_x,net.motif_L,net.oligos,net.oligos_p);
    	z=z+tz.*str_p; %*net.sequence_L*ndata;
    else
	z=z+tz;
    end	
end

a=z*net.w2+ones(ndata,1)*net.b2;        %out unites
%end added wang

switch net.outfn

  case 'linear'    % Linear outputs
    y = a;
  case 'logistic'  % Logistic outputs
    % Prevent overflow and underflow: use same bounds as mlperr
    % Ensure that log(1-y) is computable: need exp(a) > eps
    maxcut = -log(eps);
    % Ensure that log(y) is computable
    mincut = -log(1/realmin - 1);
    a = min(a, maxcut);
    a = max(a, mincut);
    y = 1./(1 + exp(-a));

  case 'softmax'   % Softmax outputs
  
    % Prevent overflow and underflow: use same bounds as glmerr
    % Ensure that sum(exp(a), 2) does not overflow
    maxcut = log(realmax) - log(net.nout);
    % Ensure that exp(a) > 0
    mincut = log(realmin);
    a = min(a, maxcut);
    a = max(a, mincut);
    temp = exp(a);
    y = temp./(sum(temp, 2)*ones(1, net.nout));

  otherwise
    error(['Unknown activation function ', net.outfn]);  
end
