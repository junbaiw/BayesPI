clear all
close all
%Input parameters
fileexp='demo_in/demo_swi4_0.05Kseq_cacgaaaa.txt'	%	demo_0.05Kseq_cacgaaaa.txt'	%demo_0.05Kseq_gctggt.txt'	%'demo_in/demo_0.05Kseq_gcctcgaagcga.txt'
fileseq='demo_in/demo_swi4_0.05Kseq_cacgaaaa.fa'	%	demo_0.05Kseq_cacgaaaa.fa'	%demo_0.05Kseq_gctggt.fa'	%'demo_in/demo_0.05Kseq_gcctcgaagcga.fa'
filenuc=[];
L=[8:12]
max_loop=6
seed=[]; %'TGACTC'
nhidden=1
out_fold='demo_out/demo_in/swi4_0.05k'
percent_selection=1;
pcutoff=1e-10;
fileann=[];
isreverse=0;    %is reverse experiment
isrepeat=0;     %is DNA sequence be repeated masked
file_nucleosome=[]; %nucleosome file

%Predict motifs
[record_net,x_binary,target]=bayes_motif_finding_loop(fileexp,fileseq,L,max_loop,seed,nhidden,out_fold,percent_selection,pcutoff,fileann,...
    file_nucleosome,isreverse,isrepeat);

%Export matrix to AffinityLogo format for visualization
export2AffinityLogo(record_net,fileexp,L,out_fold);

break;


