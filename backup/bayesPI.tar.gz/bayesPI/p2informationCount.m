function IC=p2informationCount(rel_w)
%ACGT=1,2,3,4 row
[r,c]=size(rel_w);

%compute uncertainty of each position
%Nuc Acids Res. 18: 1990, 6097-6100
for i=1:c
	H(i)=-( rel_w(1,i)*log2(rel_w(1,i))+ rel_w(2,i)*log2(rel_w(2,i))+...
		rel_w(3,i)*log2(rel_w(3,i))+ rel_w(4,i)*log2(rel_w(4,i)) );
end
R=2-H;

for i=1:c
    hight_of_base(1,i)=rel_w(1,i)*R(i);
     hight_of_base(2,i)=rel_w(2,i)*R(i);
    hight_of_base(3,i)=rel_w(3,i)*R(i);
     hight_of_base(4,i)=rel_w(4,i)*R(i);
end
IC=hight_of_base;
	
