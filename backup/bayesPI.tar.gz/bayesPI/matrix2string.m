function str=matrix2string(w)
%transform string to weight matrix representation
%
chars = {'a', 'c', 'g', 't'};
len=size(w,1);
str=[];
for i=1:len
 [mw,idx]=max(w(i,:));
 str=[str,strvcat(chars(idx))]; 
end
