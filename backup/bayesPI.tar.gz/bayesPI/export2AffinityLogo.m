function export2AffinityLogo(record_net,fileexp,L,out_fold)
%Export all matrix to AffinityLogo format for visualization
global isnucleosome
%
%transform energy to frequency and export to AffinityLogo format for print
num_of_nets=size(record_net,2)

for i=1:num_of_nets
	for jj=1:size(record_net{i}.w1,2)
        if isnucleosome
            E=record_net{i}.w1(1:end-1*record_net{i}.nhidden,jj);
        else
            E=record_net{i}.w1(:,jj);
        end
        F=reshape(exp(-E),4,record_net{i}.motif_L)';
        str=matrix2string(F);
        out_file=[out_fold,'/',fileexp,'_mlpout_L',num2str(record_net{i}.motif_L),'_',num2str(i),'_',num2str(jj),'.mlp'];
        fid=fopen(out_file,'wt');
        fprintf(fid, '%s\n',[str,char(9),'#',char(9),fileexp]);
        fprintf(fid, '%s\n',['0.001     #       p-value']);
        fprintf(fid, '%s\n', ['8642     #       bonferroni' ]);
        fprintf(fid, '%s\n', ['0        #       derived from leading strand']);
        fprintf(fid, '%s\n', ['#        a       c       g       t']);
        for j=1:size(F,1)
                fprintf(fid, '%s\n', [str(j),char(9),num2str(F(j,1)),char(9),num2str(F(j,2)),char(9),num2str(F(j,3)),char(9),num2str(F(j,4))]);
        end
        fclose(fid);
	end
end

